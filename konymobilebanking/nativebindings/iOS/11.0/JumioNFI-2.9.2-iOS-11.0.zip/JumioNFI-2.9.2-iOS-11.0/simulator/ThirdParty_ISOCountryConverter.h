#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_ISOCountryConverter_symbols(JSContext*);
@protocol ISOCountryConverterInstanceExports<JSExport>
@end
@protocol ISOCountryConverterClassExports<JSExport>
+(NSString *) convertToAlpha3: (NSString *) alpha2 ;
+(NSString *) convertToAlpha2: (NSString *) alpha3 ;
@end
#pragma clang diagnostic pop