#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_NetverifyDocumentSelectionButton_symbols(JSContext*);
@protocol NetverifyDocumentSelectionButtonInstanceExports<JSExport, NetverifyAppearanceInstanceExports_>
-(UIColor *) backgroundColorForState: (UIControlState) state ;
-(UIColor *) iconColorForState: (UIControlState) state ;
-(void) setBackgroundColor: (UIColor *) backgroundColor forState: (UIControlState) state ;
-(void) setIconColor: (UIColor *) iconColor forState: (UIControlState) state ;
@end
@protocol NetverifyDocumentSelectionButtonClassExports<JSExport, NetverifyAppearanceClassExports_>
@end
#pragma clang diagnostic pop