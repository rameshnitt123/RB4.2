#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_NetverifyFallbackButton_symbols(JSContext*);
@protocol NetverifyFallbackButtonInstanceExports<JSExport, NetverifyAppearanceInstanceExports_>
@property (nonatomic,strong) UIColor * borderColor;
-(UIColor *) backgroundColorForState: (UIControlState) state ;
-(void) setBackgroundColor: (UIColor *) backgroundColor forState: (UIControlState) state ;
@end
@protocol NetverifyFallbackButtonClassExports<JSExport, NetverifyAppearanceClassExports_>
@end
#pragma clang diagnostic pop