#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_DocumentVerificationViewController_symbols(JSContext*);
@protocol DocumentVerificationViewControllerInstanceExports<JSExport>
JSExportAs(initWithConfiguration,
-(id) jsinitWithConfiguration: (DocumentVerificationConfiguration *) configuration );
-(NSString *) sdkVersion;
@end
@protocol DocumentVerificationViewControllerClassExports<JSExport>
@end
@protocol DocumentVerificationConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (assign,nonatomic) JumioDataCenter dataCenter;
@property (nonatomic,strong) NSString * merchantReportingCriteria;
@property (nonatomic,strong) NSString * country;
@property (nonatomic,strong) NSString * additionalInformation;
@property (assign,nonatomic) JumioCameraPosition cameraPosition;
@property (nonatomic,strong) NSString * merchantScanReference;
@property (nonatomic,strong) NSString * documentName;
@property (assign,nonatomic) UIStatusBarStyle statusBarStyle;
@property (nonatomic,strong) NSString * customDocumentCode;
@property (nonatomic,weak) id delegate;
@property (nonatomic,strong) NSString * callbackUrl;
@property (nonatomic,strong) NSString * customerId;
@property (nonatomic,strong) NSString * type;
@property (nonatomic,strong) NSString * merchantApiSecret;
@property (nonatomic,strong) NSString * merchantApiToken;
@end
@protocol DocumentVerificationConfigurationClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol DocumentVerificationViewControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) documentVerificationViewController: (DocumentVerificationViewController *) documentVerificationViewController didFinishWithScanReference: (NSString *) scanReference ;
-(void) documentVerificationViewController: (DocumentVerificationViewController *) documentVerificationViewController didFinishWithError: (NSError *) error ;
@end
@protocol DocumentVerificationViewControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop