#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_NetverifyMrzData_symbols(JSContext*);
@protocol NetverifyMrzDataInstanceExports<JSExport>
@property (nonatomic,strong) NSString * line3;
@property (nonatomic,strong) NSString * line2;
@property (nonatomic,strong) NSString * line1;
@property (assign,nonatomic) NetverifyMRZFormat format;
-(BOOL) compositeValid;
-(BOOL) personalNumberValid;
-(BOOL) idNumberValid;
-(BOOL) expiryDateValid;
-(BOOL) dobValid;
@end
@protocol NetverifyMrzDataClassExports<JSExport>
@end
#pragma clang diagnostic pop