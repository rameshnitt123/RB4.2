#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([JMNavigationController class], @protocol(JMNavigationControllerInstanceExports));
	class_addProtocol([JMNavigationController class], @protocol(JMNavigationControllerClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"JMNavigationControllerTransitionTypePushPop"] = @0UL;
	context[@"JMNavigationControllerTransitionTypeCustom"] = @1UL;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void ThirdParty_JMNavigationControllerProtocols()
{
	(void)@protocol(JMAnimator);
}
void load_ThirdParty_JMNavigationController_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
