#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_NetverifyDocumentData_symbols(JSContext*);
@protocol NetverifyDocumentDataInstanceExports<JSExport>
@property (nonatomic,strong) NSDate * issuingDate;
@property (nonatomic,strong) NSString * addressLine;
@property (nonatomic,strong) NSString * originatingCountry;
@property (nonatomic,strong) NSString * city;
@property (nonatomic,strong) NSString * middleName;
@property (nonatomic,strong) NSDate * expiryDate;
@property (nonatomic,strong) UIImage * faceImage;
@property (nonatomic,strong) NSString * issuingCountry;
@property (nonatomic,strong) NSString * personalNumber;
@property (nonatomic,strong) UIImage * backImage;
@property (nonatomic,strong) NSString * idNumber;
@property (nonatomic,strong) NetverifyMrzData * mrzData;
@property (nonatomic,strong) NSString * selectedCountry;
@property (nonatomic,strong) NSString * subdivision;
@property (nonatomic,strong) NSString * firstName;
@property (nonatomic,strong) NSDate * dob;
@property (nonatomic,strong) NSString * lastName;
@property (assign,nonatomic) NetverifyDocumentType selectedDocumentType;
@property (nonatomic,strong) UIImage * frontImage;
@property (nonatomic,strong) NSString * postCode;
@property (assign,nonatomic) NetverifyGender gender;
@property (nonatomic,strong) NSString * optionalData1;
@property (nonatomic,strong) NSString * optionalData2;
@property (assign,nonatomic) NetverifyExtractionMethod extractionMethod;
@end
@protocol NetverifyDocumentDataClassExports<JSExport>
@end
#pragma clang diagnostic pop