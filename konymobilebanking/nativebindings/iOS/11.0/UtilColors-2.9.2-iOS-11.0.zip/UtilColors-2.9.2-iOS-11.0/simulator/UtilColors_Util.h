#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UtilColors_Util_symbols(JSContext*);
@protocol UtilInstanceExports<JSExport>
-(void) setColorOverlayStandardWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBorderColorFallbackButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBackgroundColorPositiveButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBackgroundColorFallbackButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setForegroundColorWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBorderColorNegativeButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setTitleColorPositiveButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setTitleColorFallbackButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setColorOverlayInvalidWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBackgroundColorWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setTintColorWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setTitleTextAttributesWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setColorOverlayValidWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setTitleColorNegativeButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBorderColorPositiveButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
-(void) setBackgroundColorNegativeButtonWithR: (int) r G: (int) g B: (int) b A: (float) a ;
@end
@protocol UtilClassExports<JSExport>
@end
#pragma clang diagnostic pop