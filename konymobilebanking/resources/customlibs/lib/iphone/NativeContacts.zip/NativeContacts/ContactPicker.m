//
//  ContactPicker.m
//  AccessNativeContacts
//
//  Created by Girish Lingarajappa Haniyamballi on 12/10/18.
//  Copyright © 2018 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import "ContactPicker.h"
#import "CallBack.h"
#import "lglobals.h"

#define FIRSTNAME       @"firstName"
#define LASTNAME        @"lastName"
#define MIDDLENAME      @"middleName"
#define PHONENUMBER     @"phone"
#define PHONENUMBERS    @"phones"
#define POSTALADDRESS   @"postal"
#define EMAIL           @"email"
#define EMAILS          @"emails"
#define COMPANY         @"company"
#define JOBTITLE        @"jobtitle"
#define DISPLAYNAME     @"displayname"

@implementation ContactPicker

-(void)selectSingleContact :(CallBack *)callback{
    if (callback) {
        self.callback = callback;
    }
    CNContactPickerViewController *contactPicker = [[CNContactPickerViewController alloc] init];
    
    contactPicker.delegate = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:contactPicker animated:YES completion:nil];
    });
}

-(void)selectSinglePhoneNumber :(CallBack *)callback {
    
    if (callback) {
        self.callback = callback;
    }
    CNContactPickerViewController *contactPicker = [[CNContactPickerViewController alloc] init];
    contactPicker.delegate = self;
    contactPicker.displayedPropertyKeys =  @[CNContactPhoneNumbersKey];
    
    contactPicker.predicateForEnablingContact = [NSPredicate predicateWithFormat:@"phoneNumbers.@count > 0"];
    contactPicker.predicateForSelectionOfContact = [NSPredicate predicateWithFormat:@"phoneNumbers.@count == 0"];
    contactPicker.predicateForSelectionOfProperty = [NSPredicate predicateWithFormat:@"key == 'phoneNumbers'"];
    
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:contactPicker animated:YES completion:nil];
    });

}

-(void)selectSingleEmail :(CallBack *)callback {

    if (callback) {
        self.callback = callback;
    }

    CNContactPickerViewController *contactPicker = [[CNContactPickerViewController alloc] init];
    contactPicker.delegate = self;
    contactPicker.displayedPropertyKeys =  @[CNContactEmailAddressesKey];
    
    contactPicker.predicateForEnablingContact = [NSPredicate predicateWithFormat:@"emailAddresses.@count > 0"];
    contactPicker.predicateForSelectionOfContact = [NSPredicate predicateWithFormat:@"emailAddresses.@count == 0"];
    
    contactPicker.predicateForSelectionOfProperty = [NSPredicate predicateWithFormat:@"key == 'emailAddresses'"];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:contactPicker animated:YES completion:nil];
    });

}


- (void)contactPickerDidCancel:(CNContactPickerViewController *)picker{
    NSLog(@"Cancelled");
}

- (void)contactPicker:(CNContactPickerViewController *)picker didSelectContact:(CNContact *)contact{

    

    NSDictionary* selectedContact = nil;

    if (contact) {

        selectedContact = [self convertCNContactToDictionary:contact];

    }else{

        selectedContact = @{};

    }

    

    NSError *error;

    NSString *jsonString = @"";

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:selectedContact

                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string

                                                         error:&error];

    

    if (! jsonData) 
	{

        NSLog(@"Got an error: %@", error);

    } else {

        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];

    }

    

    if (self.callback != nil) {

        NSArray *args = [[NSArray alloc] initWithObjects:jsonString, nil];

        executeClosure(self.callback, args, false);

        //doExecuteClosure(self.callback, args);

        [args release];

    }

}

- (void)contactPicker:(CNContactPickerViewController *)picker didSelectContactProperty:(CNContactProperty *)contactProperty{

 

    NSString* propertyName = @"";

    if ([contactProperty.key isEqualToString:@"phoneNumbers"]) {

        propertyName = @"phone";

    }else if ([contactProperty.key isEqualToString:@"emailAddresses"]){

        propertyName = @"email";

    }

    

    NSMutableDictionary *selectedProperty = [NSMutableDictionary dictionary];

    [selectedProperty addEntriesFromDictionary:[self selectedContactNamesFromCNContact:contactProperty.contact]];

    if (self.callback != nil) {

        if ([contactProperty.value isKindOfClass:[NSString class]]) {

            selectedProperty[propertyName] = contactProperty.value;

        }else{

            selectedProperty[propertyName] = [contactProperty.value stringValue];

        }

        

        

        NSError *error;

        NSString *jsonString = @"";

        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:selectedProperty

                                                           options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string

                                                             error:&error];

        

        if ( !jsonData ) 
		{

            NSLog(@"Got an error: %@", error);

        } else {

            jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];

        }

        NSArray *args = [[NSArray alloc] initWithObjects:jsonString, nil];

        doExecuteClosure(self.callback, args);

        [args release];

    }

 

    

}

#pragma mark - Helper functions
- (NSArray*)phoneNumbersFromCNContact:(CNContact *)contactObj {
    NSMutableArray *phoneNumbers = [NSMutableArray array];
    if([contactObj areKeysAvailable:@[CNContactPhoneNumbersKey]]) {
        
        for (CNLabeledValue<CNPhoneNumber *> *obj in contactObj.phoneNumbers) {
            if(obj.value && obj.value.stringValue){
                [phoneNumbers addObject:obj.value.stringValue];
            }
        }
        
    }
    return phoneNumbers;
}

- (void)postalAddressFromCNContact:(NSMutableDictionary *)contact contactObj:(CNContact *)contactObj {
    if ([contactObj areKeysAvailable:@[CNContactPostalAddressesKey]]) {
        
        NSMutableArray *postalAddresses = [NSMutableArray array];
        for (CNLabeledValue<CNPostalAddress *> *obj in contactObj.postalAddresses) {
            NSMutableDictionary *postalAddress = [NSMutableDictionary dictionary];
            if(obj.label){
                [postalAddress setObject:obj.label forKey:@"name"];
            }
            if(obj.value){
                if (obj.value.street)
                {
                    [postalAddress setObject:obj.value.street forKey:@"street"];
                }
                if (obj.value.city)
                {
                    [postalAddress setObject:obj.value.city forKey:@"city"];
                }
                if (obj.value.state)
                {
                    [postalAddress setObject:obj.value.state forKey:@"state"];
                }
                if (obj.value.country)
                {
                    [postalAddress setObject:obj.value.country forKey:@"country"];
                }
                if (obj.value.postalCode)
                {
                    [postalAddress setObject:obj.value.postalCode forKey:@"zipcode"];
                }
                if(obj.value.ISOCountryCode) {
                    [postalAddress setObject:obj.value.ISOCountryCode forKey:@"countrycode"];
                }
            }
            [postalAddresses addObject:postalAddress];
        }
        [contact setObject:postalAddresses forKey:POSTALADDRESS];
    }
}

- (NSMutableArray *)emailsForContact:(CNContact *)contactObj {
    NSMutableArray *emailAddresses = [NSMutableArray array];
    if ([contactObj areKeysAvailable:@[CNContactEmailAddressesKey]]) {
        for (CNLabeledValue<NSString *> *obj in contactObj.emailAddresses) {
            if(obj.value){
                [emailAddresses addObject:obj.value];
            }
        }
    }
    return emailAddresses;
}

- (NSMutableDictionary *)selectedContactNamesFromCNContact:(CNContact *)contactObj {
    NSMutableDictionary *contactNames =  [NSMutableDictionary dictionaryWithObjectsAndKeys:@"",FIRSTNAME,@"",MIDDLENAME,@"",LASTNAME, nil ];
    //firstname
    if ([contactObj isKeyAvailable:CNContactGivenNameKey]) [contactNames setObject:contactObj.givenName forKey:FIRSTNAME];
    //last name
    if ([contactObj isKeyAvailable:CNContactFamilyNameKey]) [contactNames setObject:contactObj.familyName forKey:LASTNAME];
    //middle name
    if ([contactObj isKeyAvailable:CNContactMiddleNameKey]) [contactNames setObject:contactObj.middleName forKey:MIDDLENAME];
    return contactNames;
}

- (NSDictionary *)convertCNContactToDictionary:(CNContact *)contactObj{
    
    NSMutableDictionary *contact = [[NSMutableDictionary alloc]init];
    if(contactObj){
        
        NSMutableDictionary * contactNames = [self selectedContactNamesFromCNContact:contactObj];
        [contact addEntriesFromDictionary:contactNames];
        
        //list of available phone numbers
        [contact setObject:[self phoneNumbersFromCNContact:contactObj]forKey:PHONENUMBERS];
        
        //extract postal addresses
        [self postalAddressFromCNContact:contact contactObj:contactObj];
        
        //extract email addreesses
        [contact setObject:[self emailsForContact:contactObj] forKey:EMAILS];
                
    }
    return contact;
}
@end
