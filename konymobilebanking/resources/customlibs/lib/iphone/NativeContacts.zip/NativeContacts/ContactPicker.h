//
//  ContactPicker.h
//  AccessNativeContacts
//
//  Created by Girish Lingarajappa Haniyamballi on 12/10/18.
//  Copyright © 2018 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>

NS_ASSUME_NONNULL_BEGIN

@class CallBack;

@interface ContactPicker : UIViewController <CNContactViewControllerDelegate, CNContactPickerDelegate>

@property (retain) CallBack *callback;

-(void)selectSingleContact:(CallBack *)callback;

-(void)selectSinglePhoneNumber:(CallBack *)callback;

-(void)selectSingleEmail :(CallBack *)callback;

@end

NS_ASSUME_NONNULL_END
