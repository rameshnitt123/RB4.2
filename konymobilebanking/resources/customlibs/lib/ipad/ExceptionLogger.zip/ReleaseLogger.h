
#import <Foundation/Foundation.h>

@interface ReleaseLogger : NSObject

+ (void)logInConsole:(NSString *)msg;


@end
