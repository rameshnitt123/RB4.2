#import "ReleaseLogger.h"

@implementation ReleaseLogger


+ (void)logInConsole:(NSString *)msg {
	NSLog(@"%@",msg);
}

@end